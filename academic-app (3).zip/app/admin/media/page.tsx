"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  Bell,
  Calendar,
  CreditCard,
  FileImage,
  FileVideo,
  Home,
  ImageIcon,
  LogOut,
  Menu,
  Settings,
  Trash2,
  Upload,
  Users,
  Video,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminMediaPage() {
  const router = useRouter()
  const [mediaItems, setMediaItems] = useState([
    {
      id: 1,
      type: "image",
      name: "Campus principal.jpg",
      url: "/placeholder.svg?height=200&width=300",
      date: "15/05/2024",
    },
    {
      id: 2,
      type: "image",
      name: "Salle de classe.jpg",
      url: "/placeholder.svg?height=200&width=300",
      date: "10/05/2024",
    },
    { id: 3, type: "video", name: "Présentation école.mp4", url: "#", date: "05/05/2024" },
    {
      id: 4,
      type: "image",
      name: "Bibliothèque.jpg",
      url: "/placeholder.svg?height=200&width=300",
      date: "01/05/2024",
    },
  ])

  const [newMedia, setNewMedia] = useState({
    name: "",
    type: "image",
    file: null,
  })

  const handleDeleteMedia = (id) => {
    setMediaItems(mediaItems.filter((item) => item.id !== id))
  }

  const handleFileChange = (e) => {
    // Dans une application réelle, vous implémenteriez ici le téléchargement de fichier
    const file = e.target.files[0]
    if (file) {
      setNewMedia({
        ...newMedia,
        name: file.name,
        file: file,
      })
    }
  }

  const handleAddMedia = () => {
    // Dans une application réelle, vous implémenteriez ici le téléchargement vers un service de stockage
    const id = mediaItems.length + 1
    const newItem = {
      id,
      type: newMedia.type,
      name: newMedia.name,
      url: newMedia.type === "image" ? "/placeholder.svg?height=200&width=300" : "#",
      date: new Date().toLocaleDateString(),
    }
    setMediaItems([...mediaItems, newItem])
    setNewMedia({
      name: "",
      type: "image",
      file: null,
    })
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">
            AcadémieApp <span className="text-primary text-sm ml-2">Admin</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/admin/dashboard" className="text-foreground/60 hover:text-foreground">
              Tableau de bord
            </Link>
            <Link href="/admin/users" className="text-foreground/60 hover:text-foreground">
              Utilisateurs
            </Link>
            <Link href="/admin/schedule" className="text-foreground/60 hover:text-foreground">
              Horaires
            </Link>
            <Link href="/admin/news" className="text-foreground/60 hover:text-foreground">
              Actualités
            </Link>
            <Link href="/admin/media" className="text-foreground font-medium">
              Médias
            </Link>
            <Link href="/admin/settings" className="text-foreground/60 hover:text-foreground">
              Paramètres
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                5
              </span>
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <Link
                    href="/admin/dashboard"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Home className="h-5 w-5" />
                    Tableau de bord
                  </Link>
                  <Link
                    href="/admin/users"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Users className="h-5 w-5" />
                    Utilisateurs
                  </Link>
                  <Link
                    href="/admin/schedule"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Calendar className="h-5 w-5" />
                    Horaires
                  </Link>
                  <Link href="/admin/news" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <CreditCard className="h-5 w-5" />
                    Actualités
                  </Link>
                  <Link href="/admin/media" className="flex items-center gap-2 font-medium">
                    <FileImage className="h-5 w-5" />
                    Médias
                  </Link>
                  <Link
                    href="/admin/settings"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Settings className="h-5 w-5" />
                    Paramètres
                  </Link>
                  <Link href="/login" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <LogOut className="h-5 w-5" />
                    Déconnexion
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
            <div className="hidden md:flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogOut className="mr-2 h-4 w-4" />
                  Déconnexion
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container">
          <div className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">Gestion des médias</h1>
            <p className="text-muted-foreground">Ajoutez, visualisez et gérez les images et vidéos de l'application.</p>
          </div>
          <div className="mt-8">
            <Tabs defaultValue="all">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="all">Tous les médias</TabsTrigger>
                <TabsTrigger value="images">Images</TabsTrigger>
                <TabsTrigger value="videos">Vidéos</TabsTrigger>
              </TabsList>
              <TabsContent value="all" className="mt-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Tous les médias</CardTitle>
                      <CardDescription>Gérez toutes vos images et vidéos</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Upload className="mr-2 h-4 w-4" />
                          Ajouter un média
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Ajouter un nouveau média</DialogTitle>
                          <DialogDescription>Téléchargez une image ou une vidéo pour l'application.</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="media-type">Type de média</Label>
                            <div className="flex gap-4">
                              <Button
                                variant={newMedia.type === "image" ? "default" : "outline"}
                                onClick={() => setNewMedia({ ...newMedia, type: "image" })}
                              >
                                <ImageIcon className="mr-2 h-4 w-4" />
                                Image
                              </Button>
                              <Button
                                variant={newMedia.type === "video" ? "default" : "outline"}
                                onClick={() => setNewMedia({ ...newMedia, type: "video" })}
                              >
                                <Video className="mr-2 h-4 w-4" />
                                Vidéo
                              </Button>
                            </div>
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="file">Fichier</Label>
                            <Input id="file" type="file" onChange={handleFileChange} />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="name">Nom du fichier</Label>
                            <Input
                              id="name"
                              value={newMedia.name}
                              onChange={(e) => setNewMedia({ ...newMedia, name: e.target.value })}
                              placeholder="Nom du fichier"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddMedia}>Télécharger</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {mediaItems.map((item) => (
                        <div key={item.id} className="rounded-md border overflow-hidden">
                          <div className="aspect-video bg-muted relative">
                            {item.type === "image" ? (
                              <img
                                src={item.url || "/placeholder.svg"}
                                alt={item.name}
                                className="object-cover w-full h-full"
                              />
                            ) : (
                              <div className="flex items-center justify-center h-full bg-black">
                                <FileVideo className="h-12 w-12 text-white" />
                              </div>
                            )}
                          </div>
                          <div className="p-3">
                            <div className="font-medium truncate">{item.name}</div>
                            <div className="text-sm text-muted-foreground">Ajouté le {item.date}</div>
                            <div className="flex justify-between items-center mt-2">
                              <div className="flex items-center">
                                {item.type === "image" ? (
                                  <ImageIcon className="h-4 w-4 text-muted-foreground mr-1" />
                                ) : (
                                  <Video className="h-4 w-4 text-muted-foreground mr-1" />
                                )}
                                <span className="text-xs text-muted-foreground">
                                  {item.type === "image" ? "Image" : "Vidéo"}
                                </span>
                              </div>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteMedia(item.id)}>
                                <Trash2 className="h-4 w-4 text-muted-foreground" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="images" className="mt-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Images</CardTitle>
                      <CardDescription>Gérez vos images</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Upload className="mr-2 h-4 w-4" />
                          Ajouter une image
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Ajouter une nouvelle image</DialogTitle>
                          <DialogDescription>Téléchargez une image pour l'application.</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="file">Fichier</Label>
                            <Input id="file" type="file" accept="image/*" onChange={handleFileChange} />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="name">Nom de l'image</Label>
                            <Input
                              id="name"
                              value={newMedia.name}
                              onChange={(e) => setNewMedia({ ...newMedia, name: e.target.value })}
                              placeholder="Nom de l'image"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddMedia}>Télécharger</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {mediaItems
                        .filter((item) => item.type === "image")
                        .map((item) => (
                          <div key={item.id} className="rounded-md border overflow-hidden">
                            <div className="aspect-video bg-muted">
                              <img
                                src={item.url || "/placeholder.svg"}
                                alt={item.name}
                                className="object-cover w-full h-full"
                              />
                            </div>
                            <div className="p-3">
                              <div className="font-medium truncate">{item.name}</div>
                              <div className="text-sm text-muted-foreground">Ajouté le {item.date}</div>
                              <div className="flex justify-end mt-2">
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteMedia(item.id)}>
                                  <Trash2 className="h-4 w-4 text-muted-foreground" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="videos" className="mt-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Vidéos</CardTitle>
                      <CardDescription>Gérez vos vidéos</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Upload className="mr-2 h-4 w-4" />
                          Ajouter une vidéo
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Ajouter une nouvelle vidéo</DialogTitle>
                          <DialogDescription>Téléchargez une vidéo pour l'application.</DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="file">Fichier</Label>
                            <Input id="file" type="file" accept="video/*" onChange={handleFileChange} />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="name">Nom de la vidéo</Label>
                            <Input
                              id="name"
                              value={newMedia.name}
                              onChange={(e) => setNewMedia({ ...newMedia, name: e.target.value })}
                              placeholder="Nom de la vidéo"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddMedia}>Télécharger</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                      {mediaItems
                        .filter((item) => item.type === "video")
                        .map((item) => (
                          <div key={item.id} className="rounded-md border overflow-hidden">
                            <div className="aspect-video bg-black flex items-center justify-center">
                              <FileVideo className="h-12 w-12 text-white" />
                            </div>
                            <div className="p-3">
                              <div className="font-medium truncate">{item.name}</div>
                              <div className="text-sm text-muted-foreground">Ajouté le {item.date}</div>
                              <div className="flex justify-end mt-2">
                                <Button variant="ghost" size="icon" onClick={() => handleDeleteMedia(item.id)}>
                                  <Trash2 className="h-4 w-4 text-muted-foreground" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
