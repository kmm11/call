"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import {
  Bell,
  Calendar,
  CreditCard,
  FileImage,
  Home,
  LogOut,
  Menu,
  Plus,
  Settings,
  Trash2,
  User,
  UserPlus,
  Users,
  Shield,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminDashboardPage() {
  const router = useRouter()
  const [users, setUsers] = useState([
    { id: 1, name: "Jean Dupont", email: "jean@example.com", role: "Étudiant" },
    { id: 2, name: "Marie Martin", email: "marie@example.com", role: "Étudiant" },
    { id: 3, name: "Pierre Leroy", email: "pierre@example.com", role: "Étudiant" },
    { id: 4, name: "Sophie Dubois", email: "sophie@example.com", role: "Professeur" },
    { id: 5, name: "Admin", email: "admin@example.com", role: "Administrateur" },
  ])

  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    password: "",
    role: "Étudiant",
  })

  const handleAddUser = () => {
    const id = users.length + 1
    setUsers([...users, { id, ...newUser }])
    setNewUser({
      name: "",
      email: "",
      password: "",
      role: "Étudiant",
    })
  }

  const handleDeleteUser = (id: number) => {
    setUsers(users.filter((user) => user.id !== id))
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">
            AcadémieApp <span className="text-primary text-sm ml-2">Admin</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/admin/dashboard" className="text-foreground font-medium">
              Tableau de bord
            </Link>
            <Link href="/admin/users" className="text-foreground/60 hover:text-foreground">
              Utilisateurs
            </Link>
            <Link href="/admin/schedule" className="text-foreground/60 hover:text-foreground">
              Horaires
            </Link>
            <Link href="/admin/news" className="text-foreground/60 hover:text-foreground">
              Actualités
            </Link>
            <Link href="/admin/media" className="text-foreground/60 hover:text-foreground">
              Médias
            </Link>
            <Link href="/admin/restricted" className="text-foreground/60 hover:text-foreground">
              Zone restreinte
            </Link>
            <Link href="/admin/settings" className="text-foreground/60 hover:text-foreground">
              Paramètres
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                5
              </span>
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <Link href="/admin/dashboard" className="flex items-center gap-2 font-medium">
                    <Home className="h-5 w-5" />
                    Tableau de bord
                  </Link>
                  <Link
                    href="/admin/users"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Users className="h-5 w-5" />
                    Utilisateurs
                  </Link>
                  <Link
                    href="/admin/schedule"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Calendar className="h-5 w-5" />
                    Horaires
                  </Link>
                  <Link href="/admin/news" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <CreditCard className="h-5 w-5" />
                    Actualités
                  </Link>
                  <Link
                    href="/admin/media"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <FileImage className="h-5 w-5" />
                    Médias
                  </Link>
                  <Link
                    href="/admin/restricted"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Shield className="h-5 w-5" />
                    Zone restreinte
                  </Link>
                  <Link
                    href="/admin/settings"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Settings className="h-5 w-5" />
                    Paramètres
                  </Link>
                  <Link href="/login" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <LogOut className="h-5 w-5" />
                    Déconnexion
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
            <div className="hidden md:flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogOut className="mr-2 h-4 w-4" />
                  Déconnexion
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container">
          <div className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">Tableau de bord administrateur</h1>
            <p className="text-muted-foreground">
              Gérez les utilisateurs, les horaires, les actualités et les paramètres de l'application.
            </p>
          </div>
          <div className="mt-8">
            <Tabs defaultValue="users">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="users">Utilisateurs</TabsTrigger>
                <TabsTrigger value="schedule">Horaires</TabsTrigger>
                <TabsTrigger value="news">Actualités</TabsTrigger>
                <TabsTrigger value="settings">Paramètres</TabsTrigger>
              </TabsList>
              <TabsContent value="users" className="mt-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Gestion des utilisateurs</CardTitle>
                      <CardDescription>Ajoutez, modifiez ou supprimez des utilisateurs</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <UserPlus className="mr-2 h-4 w-4" />
                          Ajouter un utilisateur
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Ajouter un nouvel utilisateur</DialogTitle>
                          <DialogDescription>
                            Remplissez les informations pour créer un nouvel utilisateur.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="name">Nom complet</Label>
                            <Input
                              id="name"
                              value={newUser.name}
                              onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="email">Email</Label>
                            <Input
                              id="email"
                              type="email"
                              value={newUser.email}
                              onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="password">Mot de passe</Label>
                            <Input
                              id="password"
                              type="password"
                              value={newUser.password}
                              onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                            />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="role">Rôle</Label>
                            <Select
                              value={newUser.role}
                              onValueChange={(value) => setNewUser({ ...newUser, role: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionnez un rôle" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Étudiant">Étudiant</SelectItem>
                                <SelectItem value="Professeur">Professeur</SelectItem>
                                <SelectItem value="Administrateur">Administrateur</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <DialogFooter>
                          <Button onClick={handleAddUser}>Ajouter</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {users.map((user) => (
                        <div key={user.id} className="flex items-center justify-between rounded-md border p-4">
                          <div className="flex items-center gap-4">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                              <User className="h-5 w-5 text-primary" />
                            </div>
                            <div>
                              <div className="font-medium">{user.name}</div>
                              <div className="text-sm text-muted-foreground">{user.email}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <div className="rounded-full bg-muted px-2 py-1 text-xs font-medium">{user.role}</div>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteUser(user.id)}>
                              <Trash2 className="h-4 w-4 text-muted-foreground" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="schedule" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Gestion des horaires</CardTitle>
                    <CardDescription>Modifiez les horaires de cours</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"].map((day) => (
                        <div key={day} className="space-y-2">
                          <h3 className="font-medium">{day}</h3>
                          <div className="grid gap-2 md:grid-cols-3">
                            <div className="rounded-md border p-3">
                              <div className="font-medium">8h - 11h</div>
                              <Select defaultValue="Mathématiques">
                                <SelectTrigger>
                                  <SelectValue placeholder="Sélectionnez un cours" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Mathématiques">Mathématiques</SelectItem>
                                  <SelectItem value="Physique">Physique</SelectItem>
                                  <SelectItem value="Informatique">Informatique</SelectItem>
                                  <SelectItem value="Anglais">Anglais</SelectItem>
                                  <SelectItem value="Histoire">Histoire</SelectItem>
                                </SelectContent>
                              </Select>
                              <div className="mt-2">
                                <Label htmlFor="teacher-8h">Professeur</Label>
                                <Input id="teacher-8h" defaultValue="Prof. Dupont" className="mt-1" />
                              </div>
                            </div>
                            <div className="rounded-md border p-3">
                              <div className="font-medium">11h - 14h</div>
                              <Select defaultValue="Physique">
                                <SelectTrigger>
                                  <SelectValue placeholder="Sélectionnez un cours" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Mathématiques">Mathématiques</SelectItem>
                                  <SelectItem value="Physique">Physique</SelectItem>
                                  <SelectItem value="Informatique">Informatique</SelectItem>
                                  <SelectItem value="Anglais">Anglais</SelectItem>
                                  <SelectItem value="Histoire">Histoire</SelectItem>
                                </SelectContent>
                              </Select>
                              <div className="mt-2">
                                <Label htmlFor="teacher-11h">Professeur</Label>
                                <Input id="teacher-11h" defaultValue="Prof. Martin" className="mt-1" />
                              </div>
                            </div>
                            <div className="rounded-md border p-3">
                              <div className="font-medium">14h - 17h</div>
                              <Select defaultValue="Informatique">
                                <SelectTrigger>
                                  <SelectValue placeholder="Sélectionnez un cours" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Mathématiques">Mathématiques</SelectItem>
                                  <SelectItem value="Physique">Physique</SelectItem>
                                  <SelectItem value="Informatique">Informatique</SelectItem>
                                  <SelectItem value="Anglais">Anglais</SelectItem>
                                  <SelectItem value="Histoire">Histoire</SelectItem>
                                </SelectContent>
                              </Select>
                              <div className="mt-2">
                                <Label htmlFor="teacher-14h">Professeur</Label>
                                <Input id="teacher-14h" defaultValue="Prof. Leroy" className="mt-1" />
                              </div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button>Enregistrer les modifications</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              <TabsContent value="news" className="mt-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle>Gestion des actualités</CardTitle>
                      <CardDescription>Ajoutez ou modifiez les actualités</CardDescription>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button>
                          <Plus className="mr-2 h-4 w-4" />
                          Ajouter une actualité
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Ajouter une nouvelle actualité</DialogTitle>
                          <DialogDescription>
                            Remplissez les informations pour créer une nouvelle actualité.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                          <div className="grid gap-2">
                            <Label htmlFor="title">Titre</Label>
                            <Input id="title" />
                          </div>
                          <div className="grid gap-2">
                            <Label htmlFor="content">Contenu</Label>
                            <textarea
                              id="content"
                              className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button>Publier</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">Rentrée académique</div>
                            <div className="text-sm text-muted-foreground">Publié le 15 mai 2024</div>
                            <p className="mt-2">
                              La rentrée académique est prévue pour le 1er septembre 2024. Tous les étudiants sont priés
                              de se présenter à 8h.
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              Modifier
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4 text-muted-foreground" />
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">Examens de fin d'année</div>
                            <div className="text-sm text-muted-foreground">Publié le 10 mai 2024</div>
                            <p className="mt-2">
                              Les examens de fin d'année auront lieu du 15 au 30 juin 2024. Le calendrier détaillé sera
                              disponible prochainement.
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              Modifier
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4 text-muted-foreground" />
                            </Button>
                          </div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">Fermeture administrative</div>
                            <div className="text-sm text-muted-foreground">Publié le 5 mai 2024</div>
                            <p className="mt-2">
                              Les bureaux administratifs seront fermés du 1er au 15 août 2024 pour congés annuels.
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              Modifier
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Trash2 className="h-4 w-4 text-muted-foreground" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="settings" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Paramètres de l'application</CardTitle>
                    <CardDescription>Configurez les paramètres généraux de l'application</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <Label htmlFor="app-name">Nom de l'application</Label>
                        <Input id="app-name" defaultValue="AcadémieApp" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="academic-year">Année académique</Label>
                        <Input id="academic-year" defaultValue="2024-2025" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="contact-email">Email de contact</Label>
                        <Input id="contact-email" type="email" defaultValue="contact@academieapp.com" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="contact-phone">Téléphone de contact</Label>
                        <Input id="contact-phone" defaultValue="+123 456 789" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="address">Adresse</Label>
                        <Input id="address" defaultValue="123 Rue de l'Académie, Ville, Pays" />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button>Enregistrer les modifications</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
