"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Bell, Database, Home, Key, Lock, LogOut, Menu, Settings, Shield, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function AdminRestrictedPage() {
  const router = useRouter()
  const [isAuthorized, setIsAuthorized] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Vérifier si l'utilisateur est autorisé à accéder à cette page
  useEffect(() => {
    // Dans une application réelle, vous vérifieriez ici si l'utilisateur a le code correct
    // Pour cette démo, nous simulons une vérification
    const checkAuth = () => {
      // Simuler une vérification d'authentification
      setTimeout(() => {
        // Pour cette démo, nous supposons que l'utilisateur est autorisé
        setIsAuthorized(true)
        setIsLoading(false)
      }, 1000)
    }

    checkAuth()
  }, [router])

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Vérification des autorisations...</p>
        </div>
      </div>
    )
  }

  if (!isAuthorized) {
    return (
      <div className="flex min-h-screen items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-2xl font-bold">Accès refusé</CardTitle>
            <CardDescription>Vous n'êtes pas autorisé à accéder à cette page.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center p-8">
              <Lock className="h-16 w-16 text-muted-foreground" />
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild className="w-full">
              <Link href="/login">Retour à la page de connexion</Link>
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">
            AcadémieApp <span className="text-red-500 text-sm ml-2">Admin Restreint</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/admin/dashboard" className="text-foreground/60 hover:text-foreground">
              Tableau de bord
            </Link>
            <Link href="/admin/users" className="text-foreground/60 hover:text-foreground">
              Utilisateurs
            </Link>
            <Link href="/admin/restricted" className="text-foreground font-medium">
              Zone restreinte
            </Link>
            <Link href="/admin/settings" className="text-foreground/60 hover:text-foreground">
              Paramètres
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                2
              </span>
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <Link
                    href="/admin/dashboard"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Home className="h-5 w-5" />
                    Tableau de bord
                  </Link>
                  <Link
                    href="/admin/users"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Users className="h-5 w-5" />
                    Utilisateurs
                  </Link>
                  <Link href="/admin/restricted" className="flex items-center gap-2 font-medium">
                    <Shield className="h-5 w-5" />
                    Zone restreinte
                  </Link>
                  <Link
                    href="/admin/settings"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Settings className="h-5 w-5" />
                    Paramètres
                  </Link>
                  <Link href="/login" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <LogOut className="h-5 w-5" />
                    Déconnexion
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
            <div className="hidden md:flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogOut className="mr-2 h-4 w-4" />
                  Déconnexion
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container">
          <div className="flex flex-col gap-4">
            <div className="flex items-center gap-2">
              <h1 className="text-3xl font-bold">Zone d'administration restreinte</h1>
              <Shield className="h-6 w-6 text-red-500" />
            </div>
            <p className="text-muted-foreground">
              Cette zone est réservée aux administrateurs avec le code spécial. Vous avez accès à des fonctionnalités
              avancées.
            </p>
          </div>
          <div className="mt-8">
            <Tabs defaultValue="system">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="system">Système</TabsTrigger>
                <TabsTrigger value="database">Base de données</TabsTrigger>
                <TabsTrigger value="security">Sécurité</TabsTrigger>
              </TabsList>
              <TabsContent value="system" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Paramètres système</CardTitle>
                    <CardDescription>Configurez les paramètres avancés du système</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Mode maintenance</h3>
                          <p className="text-sm text-muted-foreground">
                            Activer le mode maintenance pour tous les utilisateurs
                          </p>
                        </div>
                        <Switch />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Journalisation avancée</h3>
                          <p className="text-sm text-muted-foreground">
                            Activer la journalisation détaillée des actions utilisateur
                          </p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Notifications système</h3>
                          <p className="text-sm text-muted-foreground">
                            Envoyer des notifications aux administrateurs en cas d'erreur système
                          </p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="system-email">Email système</Label>
                      <Input id="system-email" defaultValue="system@academieapp.com" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="backup-frequency">Fréquence des sauvegardes</Label>
                      <select
                        id="backup-frequency"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="daily">Quotidienne</option>
                        <option value="weekly">Hebdomadaire</option>
                        <option value="monthly">Mensuelle</option>
                      </select>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button>Enregistrer les modifications</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
              <TabsContent value="database" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Gestion de la base de données</CardTitle>
                    <CardDescription>Effectuez des opérations avancées sur la base de données</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="rounded-md border p-4 bg-muted/50">
                      <div className="flex items-center gap-2">
                        <Database className="h-5 w-5 text-muted-foreground" />
                        <div className="font-medium">Informations de la base de données</div>
                      </div>
                      <div className="mt-2 space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Type:</span>
                          <span>PostgreSQL</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Version:</span>
                          <span>14.5</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Taille:</span>
                          <span>256 MB</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Tables:</span>
                          <span>24</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Dernière sauvegarde:</span>
                          <span>15/05/2024 04:30</span>
                        </div>
                      </div>
                    </div>
                    <div className="grid gap-4 md:grid-cols-2">
                      <Button variant="outline" className="h-auto py-4 flex flex-col items-center justify-center">
                        <div className="font-medium">Sauvegarder la base de données</div>
                        <div className="text-xs text-muted-foreground mt-1">Créer une sauvegarde complète</div>
                      </Button>
                      <Button
                        variant="outline"
                        className="h-auto py-4 flex flex-col items-center justify-center text-destructive border-destructive/20 hover:bg-destructive/10"
                      >
                        <div className="font-medium">Purger les données temporaires</div>
                        <div className="text-xs text-muted-foreground mt-1">Supprimer les données obsolètes</div>
                      </Button>
                      <Button variant="outline" className="h-auto py-4 flex flex-col items-center justify-center">
                        <div className="font-medium">Optimiser la base de données</div>
                        <div className="text-xs text-muted-foreground mt-1">Améliorer les performances</div>
                      </Button>
                      <Button variant="outline" className="h-auto py-4 flex flex-col items-center justify-center">
                        <div className="font-medium">Restaurer une sauvegarde</div>
                        <div className="text-xs text-muted-foreground mt-1">Restaurer à partir d'une sauvegarde</div>
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="sql-query">Exécuter une requête SQL</Label>
                      <textarea
                        id="sql-query"
                        placeholder="SELECT * FROM users LIMIT 10;"
                        className="flex min-h-[100px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      />
                      <Button className="mt-2">Exécuter</Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="security" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Paramètres de sécurité</CardTitle>
                    <CardDescription>Configurez les options de sécurité avancées</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Authentification à deux facteurs</h3>
                          <p className="text-sm text-muted-foreground">
                            Exiger l'authentification à deux facteurs pour tous les administrateurs
                          </p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Verrouillage de compte</h3>
                          <p className="text-sm text-muted-foreground">
                            Verrouiller les comptes après 5 tentatives de connexion échouées
                          </p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-medium">Journalisation des connexions</h3>
                          <p className="text-sm text-muted-foreground">
                            Enregistrer toutes les tentatives de connexion
                          </p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password-policy">Politique de mot de passe</Label>
                      <select
                        id="password-policy"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="standard">Standard (8 caractères minimum)</option>
                        <option value="strong" selected>
                          Fort (12 caractères, majuscules, chiffres, symboles)
                        </option>
                        <option value="very-strong">Très fort (16 caractères, majuscules, chiffres, symboles)</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="session-timeout">Expiration de session</Label>
                      <select
                        id="session-timeout"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      >
                        <option value="15">15 minutes</option>
                        <option value="30" selected>
                          30 minutes
                        </option>
                        <option value="60">1 heure</option>
                        <option value="120">2 heures</option>
                      </select>
                    </div>
                    <div className="rounded-md border p-4 bg-amber-50 text-amber-900">
                      <div className="flex items-center gap-2">
                        <Key className="h-5 w-5" />
                        <div className="font-medium">Changer le code administrateur</div>
                      </div>
                      <div className="mt-2 space-y-2">
                        <Input type="password" placeholder="Code actuel" />
                        <Input type="password" placeholder="Nouveau code" />
                        <Input type="password" placeholder="Confirmer le nouveau code" />
                        <Button variant="outline" className="w-full">
                          Mettre à jour le code
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button>Enregistrer les modifications</Button>
                  </CardFooter>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
