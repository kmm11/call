"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, CalendarIcon, CreditCard, Home, LogOut, Menu, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function CalendarPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Événements académiques pour l'année
  const academicEvents = [
    { date: new Date(2024, 8, 1), title: "Rentrée académique" },
    { date: new Date(2024, 9, 31), title: "Fin du premier trimestre" },
    { date: new Date(2024, 11, 20), title: "Vacances de Noël" },
    { date: new Date(2025, 0, 6), title: "Reprise des cours" },
    { date: new Date(2025, 1, 28), title: "Fin du deuxième trimestre" },
    { date: new Date(2025, 3, 5), title: "Vacances de Pâques" },
    { date: new Date(2025, 3, 20), title: "Reprise des cours" },
    { date: new Date(2025, 5, 15), title: "Début des examens finaux" },
    { date: new Date(2025, 5, 30), title: "Fin des examens finaux" },
    { date: new Date(2025, 6, 15), title: "Publication des résultats" },
  ]

  // Filtrer les événements pour la date sélectionnée
  const selectedDateEvents = academicEvents.filter((event) => date && event.date.toDateString() === date.toDateString())

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">AcadémieApp</div>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-foreground/60 hover:text-foreground">
              Tableau de bord
            </Link>
            <Link href="/dashboard/schedule" className="text-foreground/60 hover:text-foreground">
              Horaires
            </Link>
            <Link href="/dashboard/payments" className="text-foreground/60 hover:text-foreground">
              Paiements
            </Link>
            <Link href="/dashboard/grades" className="text-foreground/60 hover:text-foreground">
              Notes
            </Link>
            <Link href="/dashboard/calendar" className="text-foreground font-medium">
              Calendrier
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                3
              </span>
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <Link href="/dashboard" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <Home className="h-5 w-5" />
                    Tableau de bord
                  </Link>
                  <Link
                    href="/dashboard/schedule"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <CalendarIcon className="h-5 w-5" />
                    Horaires
                  </Link>
                  <Link
                    href="/dashboard/payments"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <CreditCard className="h-5 w-5" />
                    Paiements
                  </Link>
                  <Link
                    href="/dashboard/grades"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <User className="h-5 w-5" />
                    Notes
                  </Link>
                  <Link href="/dashboard/calendar" className="flex items-center gap-2 font-medium">
                    <CalendarIcon className="h-5 w-5" />
                    Calendrier
                  </Link>
                  <Link href="/login" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <LogOut className="h-5 w-5" />
                    Déconnexion
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
            <div className="hidden md:flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogOut className="mr-2 h-4 w-4" />
                  Déconnexion
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container">
          <div className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">Calendrier académique</h1>
            <p className="text-muted-foreground">Consultez les dates importantes de l'année académique 2024-2025.</p>
          </div>
          <div className="mt-8 grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Calendrier</CardTitle>
                <CardDescription>Sélectionnez une date pour voir les événements</CardDescription>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                  // Mettre en évidence les jours avec des événements
                  modifiers={{
                    event: academicEvents.map((event) => event.date),
                  }}
                  modifiersStyles={{
                    event: {
                      fontWeight: "bold",
                      backgroundColor: "hsl(var(--primary) / 0.1)",
                      borderRadius: "0",
                    },
                  }}
                />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Événements</CardTitle>
                <CardDescription>
                  {date ? `Événements pour le ${date.toLocaleDateString()}` : "Sélectionnez une date"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {selectedDateEvents.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateEvents.map((event, index) => (
                      <div key={index} className="rounded-md border p-4">
                        <div className="font-medium">{event.title}</div>
                        <div className="text-sm text-muted-foreground">{event.date.toLocaleDateString()}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    {date ? "Aucun événement pour cette date" : "Veuillez sélectionner une date"}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Événements importants</CardTitle>
                <CardDescription>Calendrier complet de l'année académique 2024-2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {academicEvents.map((event, index) => (
                    <div key={index} className="rounded-md border p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="font-medium">{event.title}</div>
                          <div className="text-sm text-muted-foreground">{event.date.toLocaleDateString()}</div>
                        </div>
                        <Button variant="outline" size="sm" onClick={() => setDate(event.date)}>
                          Voir
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
