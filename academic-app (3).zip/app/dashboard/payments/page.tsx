"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, Calendar, CreditCard, Download, Home, LogOut, Menu, Search, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"

export default function PaymentsPage() {
  const [searchTerm, setSearchTerm] = useState("")

  // Données de paiement de l'étudiant
  const payments = [
    {
      id: 1,
      description: "Frais d'inscription",
      amount: 500,
      date: "15/09/2023",
      status: "Payé",
      reference: "INS-2023-001",
    },
    {
      id: 2,
      description: "Premier trimestre",
      amount: 1000,
      date: "01/10/2023",
      status: "Payé",
      reference: "T1-2023-001",
    },
    {
      id: 3,
      description: "Deuxième trimestre",
      amount: 1000,
      date: "05/01/2024",
      status: "Payé",
      reference: "T2-2024-001",
    },
    {
      id: 4,
      description: "Troisième trimestre",
      amount: 1000,
      date: "À payer avant le 01/04/2024",
      status: "En attente",
      reference: "T3-2024-001",
    },
    {
      id: 5,
      description: "Frais de bibliothèque",
      amount: 50,
      date: "20/09/2023",
      status: "Payé",
      reference: "BIB-2023-001",
    },
    {
      id: 6,
      description: "Activités sportives",
      amount: 75,
      date: "15/10/2023",
      status: "Payé",
      reference: "SPO-2023-001",
    },
  ]

  // Filtrer les paiements en fonction du terme de recherche
  const filteredPayments = payments.filter(
    (payment) =>
      payment.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      payment.date.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  // Calculer le total payé et le total dû
  const totalPaid = payments
    .filter((payment) => payment.status === "Payé")
    .reduce((sum, payment) => sum + payment.amount, 0)
  const totalDue = payments
    .filter((payment) => payment.status === "En attente")
    .reduce((sum, payment) => sum + payment.amount, 0)
  const totalFees = totalPaid + totalDue

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">AcadémieApp</div>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-foreground/60 hover:text-foreground">
              Tableau de bord
            </Link>
            <Link href="/dashboard/schedule" className="text-foreground/60 hover:text-foreground">
              Horaires
            </Link>
            <Link href="/dashboard/payments" className="text-foreground font-medium">
              Paiements
            </Link>
            <Link href="/dashboard/grades" className="text-foreground/60 hover:text-foreground">
              Notes
            </Link>
            <Link href="/dashboard/calendar" className="text-foreground/60 hover:text-foreground">
              Calendrier
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                3
              </span>
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <Link href="/dashboard" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <Home className="h-5 w-5" />
                    Tableau de bord
                  </Link>
                  <Link
                    href="/dashboard/schedule"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Calendar className="h-5 w-5" />
                    Horaires
                  </Link>
                  <Link href="/dashboard/payments" className="flex items-center gap-2 font-medium">
                    <CreditCard className="h-5 w-5" />
                    Paiements
                  </Link>
                  <Link
                    href="/dashboard/grades"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <User className="h-5 w-5" />
                    Notes
                  </Link>
                  <Link
                    href="/dashboard/calendar"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Calendar className="h-5 w-5" />
                    Calendrier
                  </Link>
                  <Link href="/login" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <LogOut className="h-5 w-5" />
                    Déconnexion
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
            <div className="hidden md:flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogOut className="mr-2 h-4 w-4" />
                  Déconnexion
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container">
          <div className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">Paiements</h1>
            <p className="text-muted-foreground">Consultez l'historique de vos paiements et les montants dus.</p>
          </div>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Total payé</CardTitle>
                <CardDescription>Montant total déjà payé</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{totalPaid} €</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Montant dû</CardTitle>
                <CardDescription>Paiements en attente</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">{totalDue} €</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Total des frais</CardTitle>
                <CardDescription>Montant total pour l'année</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalFees} €</div>
              </CardContent>
            </Card>
          </div>
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Historique des paiements</CardTitle>
                <CardDescription>Tous vos paiements pour l'année académique 2023-2024</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4 flex items-center gap-2">
                  <Search className="h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Rechercher un paiement..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="max-w-sm"
                  />
                </div>
                <div className="space-y-4">
                  {filteredPayments.map((payment) => (
                    <div
                      key={payment.id}
                      className={`rounded-md border p-4 ${payment.status === "En attente" ? "bg-muted/50" : ""}`}
                    >
                      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-2">
                        <div>
                          <div className="font-medium">{payment.description}</div>
                          <div className="text-sm text-muted-foreground">
                            {payment.status === "Payé" ? `Payé le ${payment.date}` : payment.date}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">Référence: {payment.reference}</div>
                        </div>
                        <div className="flex flex-col md:items-end gap-2">
                          <div className="font-medium">{payment.amount} €</div>
                          <div
                            className={`text-xs px-2 py-1 rounded-full ${
                              payment.status === "Payé" ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"
                            }`}
                          >
                            {payment.status}
                          </div>
                          {payment.status === "Payé" && (
                            <Button variant="outline" size="sm" className="text-xs h-8 px-2">
                              <Download className="h-3 w-3 mr-1" />
                              Reçu
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {filteredPayments.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      Aucun paiement trouvé pour votre recherche
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
