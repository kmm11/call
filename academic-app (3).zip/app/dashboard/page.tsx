"use client"

import { useState } from "react"
import Link from "next/link"
import { Bell, Calendar, CreditCard, Home, LogOut, Menu, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function DashboardPage() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">AcadémieApp</div>
          <nav className="hidden md:flex gap-6">
            <Link href="/dashboard" className="text-foreground font-medium">
              Tableau de bord
            </Link>
            <Link href="/dashboard/schedule" className="text-foreground/60 hover:text-foreground">
              Horaires
            </Link>
            <Link href="/dashboard/payments" className="text-foreground/60 hover:text-foreground">
              Paiements
            </Link>
            <Link href="/dashboard/grades" className="text-foreground/60 hover:text-foreground">
              Notes
            </Link>
            <Link href="/dashboard/calendar" className="text-foreground/60 hover:text-foreground">
              Calendrier
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-primary-foreground">
                3
              </span>
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex flex-col gap-6 py-4">
                  <Link href="/dashboard" className="flex items-center gap-2 font-medium">
                    <Home className="h-5 w-5" />
                    Tableau de bord
                  </Link>
                  <Link
                    href="/dashboard/schedule"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Calendar className="h-5 w-5" />
                    Horaires
                  </Link>
                  <Link
                    href="/dashboard/payments"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <CreditCard className="h-5 w-5" />
                    Paiements
                  </Link>
                  <Link
                    href="/dashboard/grades"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <User className="h-5 w-5" />
                    Notes
                  </Link>
                  <Link
                    href="/dashboard/calendar"
                    className="flex items-center gap-2 text-foreground/60 hover:text-foreground"
                  >
                    <Calendar className="h-5 w-5" />
                    Calendrier
                  </Link>
                  <Link href="/login" className="flex items-center gap-2 text-foreground/60 hover:text-foreground">
                    <LogOut className="h-5 w-5" />
                    Déconnexion
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
            <div className="hidden md:flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link href="/login">
                  <LogOut className="mr-2 h-4 w-4" />
                  Déconnexion
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </header>
      <main className="flex-1 p-4 md:p-6">
        <div className="container">
          <div className="flex flex-col gap-4">
            <h1 className="text-3xl font-bold">Tableau de bord</h1>
            <p className="text-muted-foreground">Bienvenue, Étudiant! Voici un aperçu de votre situation académique.</p>
          </div>
          <div className="mt-8">
            <Tabs defaultValue="news">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="news">Actualités</TabsTrigger>
                <TabsTrigger value="schedule">Horaires</TabsTrigger>
                <TabsTrigger value="payments">Paiements</TabsTrigger>
                <TabsTrigger value="grades">Notes</TabsTrigger>
              </TabsList>
              <TabsContent value="news" className="mt-6">
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Rentrée académique</CardTitle>
                      <CardDescription>Publié le 15 mai 2024</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p>
                        La rentrée académique est prévue pour le 1er septembre 2024. Tous les étudiants sont priés de se
                        présenter à 8h.
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Examens de fin d'année</CardTitle>
                      <CardDescription>Publié le 10 mai 2024</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p>
                        Les examens de fin d'année auront lieu du 15 au 30 juin 2024. Le calendrier détaillé sera
                        disponible prochainement.
                      </p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Fermeture administrative</CardTitle>
                      <CardDescription>Publié le 5 mai 2024</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p>Les bureaux administratifs seront fermés du 1er au 15 août 2024 pour congés annuels.</p>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="schedule" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Horaire de la semaine</CardTitle>
                    <CardDescription>Du lundi au samedi</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"].map((day) => (
                        <div key={day} className="space-y-2">
                          <h3 className="font-medium">{day}</h3>
                          <div className="grid gap-2 md:grid-cols-3">
                            <div className="rounded-md border p-3">
                              <div className="font-medium">8h - 11h</div>
                              <div className="text-sm text-muted-foreground">Mathématiques</div>
                              <div className="text-xs text-muted-foreground mt-1">Prof. Dupont</div>
                            </div>
                            <div className="rounded-md border p-3">
                              <div className="font-medium">11h - 14h</div>
                              <div className="text-sm text-muted-foreground">Physique</div>
                              <div className="text-xs text-muted-foreground mt-1">Prof. Martin</div>
                            </div>
                            <div className="rounded-md border p-3">
                              <div className="font-medium">14h - 17h</div>
                              <div className="text-sm text-muted-foreground">Informatique</div>
                              <div className="text-xs text-muted-foreground mt-1">Prof. Leroy</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="payments" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Paiements effectués</CardTitle>
                    <CardDescription>Historique des paiements pour l'année académique 2023-2024</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between">
                          <div>
                            <div className="font-medium">Frais d'inscription</div>
                            <div className="text-sm text-muted-foreground">Payé le 15 septembre 2023</div>
                          </div>
                          <div className="font-medium">500 €</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between">
                          <div>
                            <div className="font-medium">Premier trimestre</div>
                            <div className="text-sm text-muted-foreground">Payé le 1 octobre 2023</div>
                          </div>
                          <div className="font-medium">1000 €</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between">
                          <div>
                            <div className="font-medium">Deuxième trimestre</div>
                            <div className="text-sm text-muted-foreground">Payé le 5 janvier 2024</div>
                          </div>
                          <div className="font-medium">1000 €</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4 bg-muted/50">
                        <div className="flex justify-between">
                          <div>
                            <div className="font-medium">Troisième trimestre</div>
                            <div className="text-sm text-muted-foreground">À payer avant le 1 avril 2024</div>
                          </div>
                          <div className="font-medium">1000 €</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="grades" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Moyennes de cours</CardTitle>
                    <CardDescription>Résultats pour le semestre en cours</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">Mathématiques</div>
                            <div className="text-sm text-muted-foreground">Prof. Dupont</div>
                          </div>
                          <div className="font-medium">16/20</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">Physique</div>
                            <div className="text-sm text-muted-foreground">Prof. Martin</div>
                          </div>
                          <div className="font-medium">14/20</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">Informatique</div>
                            <div className="text-sm text-muted-foreground">Prof. Leroy</div>
                          </div>
                          <div className="font-medium">18/20</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">Anglais</div>
                            <div className="text-sm text-muted-foreground">Prof. Smith</div>
                          </div>
                          <div className="font-medium">15/20</div>
                        </div>
                      </div>
                      <div className="rounded-md border p-4 bg-primary/10">
                        <div className="flex justify-between items-center">
                          <div>
                            <div className="font-medium">Moyenne générale</div>
                          </div>
                          <div className="font-medium">15.75/20</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex flex-col items-center justify-center gap-2 md:flex-row md:gap-4">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
        </div>
      </footer>
    </div>
  )
}
