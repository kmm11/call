import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="font-bold text-xl">AcadémieApp</div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-foreground/60 hover:text-foreground">
              Accueil
            </Link>
            <Link href="#features" className="text-foreground/60 hover:text-foreground">
              Fonctionnalités
            </Link>
            <Link href="#contact" className="text-foreground/60 hover:text-foreground">
              Contact
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/login">
              <Button variant="outline">Connexion</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                    Votre portail académique complet
                  </h1>
                  <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                    Accédez à vos actualités, horaires, paiements, notes et calendrier académique en un seul endroit.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/login">
                    <Button size="lg" className="gap-1">
                      Commencer <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <img
                  src="/placeholder.svg?height=400&width=400"
                  alt="Application Preview"
                  className="rounded-lg object-cover aspect-square"
                  width={400}
                  height={400}
                />
              </div>
            </div>
          </div>
        </section>
        <section id="features" className="w-full py-12 md:py-24 lg:py-32 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Fonctionnalités</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Tout ce dont vous avez besoin pour suivre votre parcours académique
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Actualités</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Restez informé des dernières nouvelles et annonces de votre établissement.
                </p>
              </div>
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Horaires</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Consultez votre emploi du temps hebdomadaire du lundi au samedi.
                </p>
              </div>
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Paiements</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Suivez vos paiements effectués et restants en temps réel.
                </p>
              </div>
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Notes</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Accédez à vos moyennes de cours et suivez votre progression académique.
                </p>
              </div>
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Calendrier</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Visualisez le calendrier complet de l'année académique avec tous les événements importants.
                </p>
              </div>
              <div className="grid gap-1">
                <h3 className="text-xl font-bold">Administration</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Les administrateurs peuvent gérer les utilisateurs et toutes les informations de l'application.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="contact" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Contact</h2>
                <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400">
                  Besoin d'aide ou d'informations supplémentaires? Contactez-nous.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-2 lg:gap-12">
              <div className="grid gap-6">
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Adresse</h3>
                  <p className="text-gray-500 dark:text-gray-400">123 Rue de l'Académie, Ville, Pays</p>
                </div>
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Email</h3>
                  <p className="text-gray-500 dark:text-gray-400">contact@academieapp.com</p>
                </div>
                <div className="grid gap-1">
                  <h3 className="text-xl font-bold">Téléphone</h3>
                  <p className="text-gray-500 dark:text-gray-400">+123 456 789</p>
                </div>
              </div>
              <div className="grid gap-6">
                <div className="grid gap-2">
                  <h3 className="text-xl font-bold">Heures d'ouverture</h3>
                  <p className="text-gray-500 dark:text-gray-400">Lundi - Vendredi: 8h - 17h</p>
                  <p className="text-gray-500 dark:text-gray-400">Samedi: 8h - 12h</p>
                  <p className="text-gray-500 dark:text-gray-400">Dimanche: Fermé</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6">
        <div className="container flex flex-col items-center justify-center gap-4 md:flex-row md:gap-8">
          <p className="text-center text-sm text-gray-500 dark:text-gray-400">
            © 2024 AcadémieApp. Tous droits réservés.
          </p>
          <nav className="flex gap-4 sm:gap-6">
            <Link href="#" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Conditions d'utilisation
            </Link>
            <Link href="#" className="text-sm text-gray-500 hover:underline dark:text-gray-400">
              Politique de confidentialité
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}
